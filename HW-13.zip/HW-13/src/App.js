import './App.css'
import Fetch from './components/Fetch'

function App() {
  return <>
  <Fetch />
  
  
  </>
}

export default App
