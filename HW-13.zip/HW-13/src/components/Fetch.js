import { useState, useEffect } from 'react'
import classes from './Fetch.module.css'

function Fetch() {
  const [data, setData] = useState([])
  useEffect(() => {
    fetch('https://jsonplaceholder.typicode.com/photos?_start=0&_limit=5')
      .then((result) => {
        return result.json()
      })
      .then((info) => setData(info))
  }, [])

  return (
    <div className={classes.container}>
      {data.map((el) => (
        <div key={el.id} className={classes.main}>
          <div className={classes.title_id}>
           <div className={classes.title}>{el.title}</div>
            <div className={classes.id}>{el.id}</div>
          </div>
          <h5>there isn't any text in the jsonplaceholder</h5>
          <div>
            <img src={el.url} alt="123" />
          </div>
        </div>
      ))}
    </div>
  )
}
export default Fetch
